# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 15:13:02 2021

@author: Touching tap
"""

def input_data(ei):
    age = int(ei.text())
    return age
    
def input_data2(ilf):
    x = int(ilf.text())
    return x

def input_data3(eif):
    st = int(eif.text()) 
    return st

def input_data4(eo):
    el = int(eo.text())
    return el

def input_data5(eq):
    sec = int(eq.text())
    return sec

def input_data6(teamexp):
    rom = int(teamexp.text())
    return rom

def input_data7(entity):
    sup = int(entity.text())
    return sup

def input_data8(transaction):
    hlt = int(transaction.text())
    return hlt

def input_data9(length):
    fam = int(length.text())

    return fam

def input_data10(managerexp):
    fam = int(managerexp.text())
    return fam
